(()=>{
'use strict';
const $=id=>document.getElementById(id), A=JatimAnalytics;
const all=A.enrich(window.JATIM_DATA);
const MAP_TEMPLATE=window.JATIM_MAP_TEMPLATE;
const colors={Kota:'#5262e8',Kabupaten:'#0c9488'}, levelColors=['#5262e8','#0c9488','#edaa4b'];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(x,d=0)=>Number.isFinite(x)?new Intl.NumberFormat('id-ID',{minimumFractionDigits:d,maximumFractionDigits:d}).format(x):'—';
const full=n=>n.startsWith('Kota ')?n:'Kabupaten '+n;
const mean=v=>v.length?v.reduce((s,n)=>s+n,0)/v.length:null;
const json=o=>JSON.stringify(o).replace(/</g,'\\u003c').replace(/>/g,'\\u003e').replace(/&/g,'\\u0026');
const defaultMin=Math.floor(Math.min(...all.map(r=>r.ipm))),defaultMax=Math.ceil(Math.max(...all.map(r=>r.ipm)));
let rows=all,active='summary',selected=new Set(),mapMetric='sekolah',mapLevel='semua',ratioLevel='semua';
const labels={ipm:'IPM',rata_lama_sekolah:'Lama sekolah (tahun)',rasio:'Murid per guru',total_sekolah:'Jumlah sekolah',total_guru:'Jumlah guru',total_murid:'Jumlah murid',kepadatan:'Murid per sekolah',persen:'Murid SMA / murid SD (%)',murid_sd:'Jumlah murid SD',murid_smp:'Jumlah murid SMP',murid_sma:'Jumlah murid SMA'};
const value=(r,k,level='semua')=>k==='rasio'?A.measures(r,level).rasio:k==='kepadatan'?A.measures(r).kepadatan:k==='persen'?(r.murid_sd?100*r.murid_sma/r.murid_sd:null):r[k];
const avg=(data,k,level)=>mean(data.map(r=>value(r,k,level)).filter(Number.isFinite));
const config={responsive:true,displaylogo:false,scrollZoom:false,modeBarButtonsToRemove:['zoom2d','pan2d','zoomIn2d','zoomOut2d','autoScale2d','resetScale2d','lasso2d','select2d'],toImageButtonOptions:{format:'png',filename:'pendidikan_jatim_pratinjau',scale:2}};
function base(height=430){return {height,paper_bgcolor:'#fff',plot_bgcolor:'#fff',font:{family:'Segoe UI,Arial,sans-serif',size:12,color:'#41536a'},margin:{l:8,r:30,t:45,b:45},separators:',.',legend:{title:{text:''},orientation:'h',y:1.12,x:0,font:{size:11}},hoverlabel:{bgcolor:'#182d43',font:{color:'#fff',size:13}},xaxis:{showgrid:true,gridcolor:'#edf1f6',zeroline:false,automargin:true,tickfont:{size:11},title:{font:{size:12}}},yaxis:{showgrid:false,zeroline:false,automargin:true,tickfont:{size:12},title:{font:{size:12}}}};}
function plot(id,data,layout){return Plotly.react($(id),data,layout,config);}
function ranking(id,data,key,{ascending=false,limit=10,range=null,compact=false,decimals=2,level='semua',ordered=false}={}){
 const valid=data.filter(r=>Number.isFinite(value(r,key,level)));
 const sorted=(ordered?[...valid]:[...valid].sort((a,b)=>(ascending?1:-1)*(value(a,key,level)-value(b,key,level))||a.kabupaten_kota.localeCompare(b.kabupaten_kota,'id'))).slice(0,limit);
 const names=sorted.map((r,i)=>String(i+1).padStart(2,'0')+'   '+r.kabupaten_kota);
 const hi=Math.max(...valid.map(r=>value(r,key,level)),1);
 const extent=key==='ipm'?[0,100]:key==='rata_lama_sekolah'?[0,Math.max(5,Math.ceil(Math.max(...all.map(r=>r.rata_lama_sekolah))/5)*5)]:range||[0,hi*1.23];
 const traces=[];
 for(const [kind,color] of Object.entries(colors)){
  const group=sorted.map((r,i)=>({r,i})).filter(({r})=>r.jenis_wilayah===kind);
  if(!group.length)continue;
  traces.push({type:'bar',orientation:'h',name:kind,x:group.map(({r})=>value(r,key,level)),y:group.map(({i})=>names[i]),
   marker:{color,cornerradius:5},width:.58,text:group.map(({r})=>fmt(value(r,key,level),decimals)),textposition:'outside',textfont:{size:13,color:'#253b53'},cliponaxis:false,
   customdata:group.map(({r})=>[full(r.kabupaten_kota),fmt(value(r,key,level),decimals)]),hovertemplate:'<b>%{customdata[0]}</b><br>'+labels[key]+': %{customdata[1]}<extra></extra>'});
 }
 const layout=base(Math.max(compact?285:390,sorted.length*38+85));
 layout.margin={l:0,r:60,t:16,b:45};layout.showlegend=false;layout.barmode='overlay';
 const ticks=key==='ipm'?[0,25,50,75,100]:key==='rata_lama_sekolah'?Array.from({length:extent[1]/5+1},(_,i)=>i*5):[0,hi/2,hi];
 layout.xaxis={...layout.xaxis,title:{text:labels[key],font:{size:12}},range:extent,tickvals:ticks,ticktext:ticks.map(v=>fmt(v,key==='ipm'||key==='rata_lama_sekolah'||key.startsWith('total_')||key.startsWith('murid_')?0:Math.abs(v)>=100?0:1))};
 layout.yaxis={...layout.yaxis,showgrid:false,categoryorder:'array',categoryarray:names,autorange:'reversed'};
 return plot(id,traces,layout);
}
function regions(){
 const choices=all.filter(r=>$('type').value==='semua'||r.jenis_wilayah===$('type').value).sort((a,b)=>full(a.kabupaten_kota).localeCompare(full(b.kabupaten_kota),'id'));
 $('regionOptions').innerHTML=choices.map((r,i)=>`<label><input type="checkbox" data-region="${esc(r.kabupaten_kota)}" ${selected.has(r.kabupaten_kota)?'checked':''}><span>${esc(full(r.kabupaten_kota))}</span></label>`).join('');
 $('regionCount').textContent=choices.length+' pilihan tersedia. Kosong = semua.';
}
function filter(){
 const state={type:$('type').value,min:Number($('min').value),max:Number($('max').value)};
 rows=A.filter(all,state).filter(r=>!selected.size||selected.has(r.kabupaten_kota));
 $('regionLabel').textContent=selected.size===1?full([...selected][0]):selected.size?selected.size+' wilayah dipilih':'Pilih dari daftar…';
 $('coverage').innerHTML='Menampilkan <b>'+rows.length+' dari 38 wilayah</b>';
 const s=A.summary(rows),items=[['Total sekolah',s.sekolah,0],['Total guru',s.guru,0],['Total murid',s.murid,0],['Rata-rata IPM',s.ipm,2],['Lama sekolah (tahun)',s.rls,2],['Murid per guru',s.rasio,1]];
 $('kpis').innerHTML=items.map(([label,n,d])=>`<article class="kpi"><span>${label}</span><strong>${rows.length?fmt(n,d):'—'}</strong></article>`).join('');
 $('download').disabled=!rows.length;
 renderActive();
}
function summary(){
 const top=[...rows].sort((a,b)=>b.ipm-a.ipm),high=top[0],low=top.at(-1);
 $('insight').innerHTML=`Dari <b>${rows.length} wilayah</b> terpilih, IPM tertinggi ada di <b>${esc(full(high.kabupaten_kota))} (${fmt(high.ipm,2)})</b>. Selisih dengan ${esc(full(low.kabupaten_kota))}: <b>${fmt(high.ipm-low.ipm,2)} poin</b>.`;
 const range=[0,100];
 ranking('chart-high',rows,'ipm',{limit:5,range,compact:true});ranking('chart-low',rows,'ipm',{limit:5,range,compact:true,ascending:true});
 const key=$('rankMetric').value,limit=Number($('rankCount').value),decimals=key.startsWith('total_')?0:2;
 ranking('chart-ranking',rows,key,{ascending:$('rankOrder').value==='asc',limit,decimals});
 $('rankCaption').textContent=`${Math.min(limit,rows.length)} dari ${rows.length} wilayah ditampilkan. Semakin panjang batang, semakin besar nilainya. Angka di ujung batang menunjukkan nilai setiap wilayah.`;
}
function map(){
 const key=mapLevel==='semua'?'total_'+mapMetric:mapMetric+'_'+mapLevel;
 const sorted=all.map(r=>r[key]).sort((a,b)=>a-b),t1=sorted[Math.floor(sorted.length/3)],t2=sorted[Math.floor(2*sorted.length/3)];
 const points=window.JATIM_MAP_POINTS,title='Jumlah '+mapMetric+(mapLevel==='semua'?'':' '+mapLevel.toUpperCase());
 const data=rows.map(r=>{const m=A.measures(r,mapLevel),p=points[r.kabupaten_kota];return {nama:r.kabupaten_kota,lat:p[0],lon:p[1],nilai:r[key],rincian:[[title,fmt(r[key])],['Jenjang',mapLevel==='semua'?'SD, SMP, SMA':mapLevel.toUpperCase()],['IPM',fmt(r.ipm,2)],['Rata-rata lama sekolah',fmt(r.rata_lama_sekolah,2)+' tahun'],['Sekolah',fmt(m.sekolah)],['Guru',fmt(m.guru)],['Murid',fmt(m.murid)],['Murid per guru',fmt(m.rasio,2)]]};});
 const cfg={judul:title,t1,t2,warnaIpm:$('mapColor').checked,ipm:Object.fromEntries(all.map(r=>[r.kabupaten_kota,r.ipm])),ipmMin:Math.min(...all.map(r=>r.ipm)),ipmMax:Math.max(...all.map(r=>r.ipm)),atribusi:'Batas wilayah: BPS, WFP, OCHA ROAP via geoBoundaries (CC BY 3.0 IGO)'};
 $('mapCaption').textContent=rows.length+' wilayah · '+title+' · total '+fmt(rows.reduce((n,r)=>n+r[key],0));
 $('mapFrame').srcdoc=MAP_TEMPLATE.replace(/__(DATA|CFG)__/g,(_,name)=>name==='DATA'?json(data):json(cfg));
}
function schooling(){
 const order=$('schoolOrder').value,limit=Number($('schoolCount').value);
 const d=[...rows].sort((a,b)=>order==='nama'?a.kabupaten_kota.localeCompare(b.kabupaten_kota,'id'):b[order]-a[order]||a.kabupaten_kota.localeCompare(b.kabupaten_kota,'id')).slice(0,limit);
 ranking('chart-school-ipm',d,'ipm',{ordered:true,limit,compact:true});
 ranking('chart-school-years',d,'rata_lama_sekolah',{ordered:true,limit,compact:true,range:[0,Math.ceil(Math.max(...rows.map(r=>r.rata_lama_sekolah))*1.2)]});
 const first=d[0];
 $('schoolIntro').innerHTML=`Contoh membaca: <b>${esc(full(first.kabupaten_kota))}</b> memiliki <b>IPM ${fmt(first.ipm,2)} dari 100</b> dan rata-rata lama sekolah <b>${fmt(first.rata_lama_sekolah,2)} tahun</b>. Kedua grafik memakai urutan wilayah yang sama.`;
}
function ratio(){
 const limit=$('ratioAll').checked?38:10;
 ranking('chart-ratio',rows,'rasio',{level:ratioLevel,limit,decimals:1});
 ranking('chart-density',rows,'kepadatan',{limit,decimals:1});
 const totals=A.summary(rows,ratioLevel),allTotals=A.summary(rows);
 const jenjang=ratioLevel==='semua'?'SD, SMP, dan SMA':ratioLevel.toUpperCase();
 $('ratioIntro').innerHTML=`Pada jenjang <b>${jenjang}</b>, perbandingan total murid dan guru setara dengan <b>${fmt(totals.rasio,1)} murid untuk setiap 1 guru</b>. Untuk seluruh SD, SMP, dan SMA, rata-ratanya <b>${fmt(allTotals.kepadatan,1)} murid per sekolah</b>.`;
}
function level(){
 for(const metric of ['sekolah','guru','murid']){
  const vals=['sd','smp','sma'].map(j=>rows.reduce((n,r)=>n+r[metric+'_'+j],0)),total=vals.reduce((n,v)=>n+v,0),hi=Math.max(...vals,1),layout=base(275);
  layout.margin={l:6,r:115,t:15,b:40};layout.showlegend=false;
  layout.xaxis={...layout.xaxis,range:[0,hi*1.05],showticklabels:false,showgrid:false,title:{text:'Jumlah '+metric,font:{size:12}}};
  layout.yaxis={...layout.yaxis,categoryorder:'array',categoryarray:['SD','SMP','SMA'],autorange:'reversed',tickfont:{size:14}};
  plot('chart-komposisi-'+metric,[{type:'bar',orientation:'h',y:['SD','SMP','SMA'],x:vals,width:.5,marker:{color:levelColors,cornerradius:5},
   text:vals.map(n=>fmt(n)+' ('+fmt(total?n/total*100:0,1)+'%)'),textposition:'outside',textfont:{size:12,color:'#334b63'},cliponaxis:false,
   hovertemplate:'<b>%{y}</b><br>%{text} '+metric+'<extra></extra>'}],layout);
  $('komposisi-total-'+metric).textContent='Total: '+fmt(total)+' '+metric;
 }
 const jenjang=$('educationLevel').value,key=jenjang==='semua'?'total_murid':'murid_'+jenjang;
 ranking('chart-level',rows,key,{limit:$('levelAll').checked?38:10,decimals:0});
 $('levelCaption').textContent='Jumlah murid '+(jenjang==='semua'?'SD, SMP, dan SMA':jenjang.toUpperCase())+' per wilayah. Semakin panjang batang, semakin banyak muridnya.';
}
function compare(){
 const a=all.find(r=>r.kabupaten_kota===$('compareA').value),b=all.find(r=>r.kabupaten_kota===$('compareB').value);
 for(const [suffix,r]of [['A',a],['B',b]]){const entries=[['IPM',r.ipm,2],['Lama sekolah · tahun',r.rata_lama_sekolah,2],['Murid per guru',A.measures(r).rasio,2],['Total murid',r.total_murid,0]];$('compareMetrics'+suffix).innerHTML=entries.map(([label,n,d])=>`<div class="stat"><small>${label}</small><b>${fmt(n,d)}</b></div>`).join('');}
 const selisih=a.ipm-b.ipm; $('compareNote').textContent=a===b?'Anda memilih daerah yang sama. Pilih daerah berbeda untuk melihat perbandingan.':selisih===0?'Nilai IPM kedua daerah sama.':`IPM ${full(a.kabupaten_kota)} ${selisih>0?'lebih tinggi':'lebih rendah'} ${fmt(Math.abs(selisih),2)} poin dibanding ${full(b.kabupaten_kota)}.`;
}
function data(){
 const keys=[['kabupaten_kota','Kabupaten/kota'],['tahun','Tahun'],['ipm','IPM'],['rata_lama_sekolah','Lama sekolah (tahun)'],['total_sekolah','Sekolah'],['total_guru','Guru'],['total_murid','Murid'],['rasio','Murid/guru']];
 $('tableHead').innerHTML='<tr>'+keys.map(([,n])=>'<th>'+n+'</th>').join('')+'</tr>';
 $('tableBody').innerHTML=rows.map(r=>'<tr>'+keys.map(([k])=>'<td>'+(k==='kabupaten_kota'?esc(full(r[k])):k==='tahun'?r[k]:fmt(value(r,k),['ipm','rata_lama_sekolah','rasio'].includes(k)?2:0))+'</td>').join('')+'</tr>').join('');
 $('tableCaption').textContent=rows.length+' wilayah sesuai filter · tahun integrasi 2025';
}
function renderActive(){
 document.querySelectorAll('[role=tabpanel]').forEach(p=>p.hidden=p.id!=='pane-'+active||(!rows.length&&active!=='compare'));
 $('empty').hidden=rows.length>0||active==='compare';
 if(!rows.length&&active!=='compare')return;
 ({summary,map,schooling,ratio,level,compare,data})[active]();
}
function switchTab(name){active=name;document.querySelectorAll('[data-tab]').forEach(b=>{const on=b.dataset.tab===name;b.setAttribute('aria-selected',String(on));b.tabIndex=on?0:-1;});renderActive();}
function download(){if(!rows.length)return;const blob=new Blob([A.csv(rows)],{type:'text/csv;charset=utf-8;'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='indikator_jatim_pratinjau.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);}
$('regionToggle').addEventListener('click',()=>{const open=$('regionMenu').hidden;$('regionMenu').hidden=!open;$('regionToggle').setAttribute('aria-expanded',String(open));});
$('regionOptions').addEventListener('change',e=>{const n=e.target.dataset.region;if(!n)return;e.target.checked?selected.add(n):selected.delete(n);filter();});
$('clearRegions').onclick=()=>{selected.clear();regions();filter();};
document.addEventListener('click',e=>{if(!e.target.closest('.region-wrap')){$('regionMenu').hidden=true;$('regionToggle').setAttribute('aria-expanded','false');}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){$('regionMenu').hidden=true;$('regionToggle').setAttribute('aria-expanded','false');}});
$('type').onchange=()=>{selected.clear();regions();filter();};
for(const n of ['min','max'])$(n).addEventListener('change',()=>{let v=Number($(n).value);if(!Number.isFinite(v))v=n==='min'?defaultMin:defaultMax;$(n).value=Math.max(0,Math.min(100,v));if(Number($('min').value)>Number($('max').value))$(n==='min'?'max':'min').value=$(n).value;filter();});
$('reset').onclick=()=>{$('type').value='semua';$('min').value=defaultMin;$('max').value=defaultMax;selected.clear();regions();filter();};
for(const id of ['rankMetric','rankOrder','rankCount'])$(id).onchange=()=>{if(rows.length)summary();};
for(const [id,update]of [['mapMetric',v=>mapMetric=v],['mapLevel',v=>mapLevel=v],['ratioLevel',v=>ratioLevel=v]])$(id).addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;$(id).querySelectorAll('button').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));update(b.dataset.value);if(rows.length)renderActive();});
for(const id of ['mapColor','ratioAll','levelAll','schoolOrder','schoolCount','educationLevel'])$(id).onchange=()=>{if(rows.length)renderActive();};
for(const id of ['compareA','compareB']){$(id).innerHTML=[...all].sort((a,b)=>full(a.kabupaten_kota).localeCompare(full(b.kabupaten_kota),'id')).map(r=>`<option value="${esc(r.kabupaten_kota)}">${esc(full(r.kabupaten_kota))}</option>`).join('');$(id).onchange=compare;}
$('compareA').value='Kota Surabaya';$('compareB').value='Sampang';
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>switchTab(b.dataset.tab));
document.querySelector('.tabs').addEventListener('keydown',e=>{const tabs=[...document.querySelectorAll('[data-tab]')],i=tabs.findIndex(b=>b.getAttribute('aria-selected')==='true');let j;if(e.key==='ArrowRight')j=(i+1)%tabs.length;else if(e.key==='ArrowLeft')j=(i+tabs.length-1)%tabs.length;else if(e.key==='Home')j=0;else if(e.key==='End')j=tabs.length-1;else return;e.preventDefault();tabs[j].click();tabs[j].focus();});
$('download').onclick=download;$('downloadTable').onclick=download;
$('toggleFilters').onclick=()=>{const hide=$('app').classList.toggle('no-sidebar');$('toggleFilters').textContent=hide?'Tampilkan filter':'Sembunyikan filter';$('toggleFilters').setAttribute('aria-pressed',String(hide));setTimeout(()=>{document.querySelectorAll('#pane-'+active+' .js-plotly-plot').forEach(p=>Plotly.Plots.resize(p));},50);};
$('min').value=defaultMin;$('max').value=defaultMax;regions();filter();
window.__preview={all,get rows(){return rows;},get active(){return active;},summary:A.summary,version:'visual-preview-simple-bars'};
})();
