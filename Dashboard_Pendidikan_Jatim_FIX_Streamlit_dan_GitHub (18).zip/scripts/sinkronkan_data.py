#!/usr/bin/env python3
"""Sinkronisasi sumber data dan template peta menjadi file JS (tanpa paket tambahan)."""
from pathlib import Path
import json, csv
BASE = Path(__file__).resolve().parents[1]
DATA = json.loads((BASE / "data/jatim-2025.json").read_text(encoding="utf-8"))
COORDS = json.loads((BASE / "data/koordinat-wilayah.json").read_text(encoding="utf-8"))
MAP = (BASE / "maps/map-template.html").read_text(encoding="utf-8")
if len(DATA) != len(COORDS) or {d["kabupaten_kota"] for d in DATA} != set(COORDS):
    raise ValueError("Nama dan jumlah wilayah tidak konsisten antara data dan koordinat.")
for name, var, obj in [
    ("dataset.js", "JATIM_DATA", DATA),
    ("coordinates.js", "JATIM_MAP_POINTS", COORDS),
    ("map-template.js", "JATIM_MAP_TEMPLATE", MAP),
]:
    (BASE / "assets/js" / name).write_text(
        f"/* Otomatis dibuat oleh scripts/sinkronkan_data.py */\nwindow.{var} = " +
        json.dumps(obj, ensure_ascii=name != "dataset.js", separators=(",", ":")) + ";\n",
        encoding="utf-8",
    )
with (BASE / "data/jatim-2025.csv").open("w", newline="", encoding="utf-8-sig") as file:
    writer = csv.DictWriter(file, fieldnames=DATA[0].keys())
    writer.writeheader()
    writer.writerows(DATA)
print("Selesai: dataset.js, coordinates.js, map-template.js, dan CSV diperbarui.")
