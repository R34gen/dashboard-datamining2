// Jalankan: node tests/test-data.js
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const base = path.join(__dirname, '..');
const data = JSON.parse(fs.readFileSync(path.join(base, 'data/jatim-2025.json'), 'utf8'));
const coords = JSON.parse(fs.readFileSync(path.join(base, 'data/koordinat-wilayah.json'), 'utf8'));
assert.equal(data.length, 38, 'Harus ada 38 wilayah');
assert.equal(new Set(data.map(d => d.kabupaten_kota)).size, 38, 'Nama wilayah tidak boleh duplikat');
assert.equal(data.filter(d => d.kabupaten_kota.startsWith('Kota ')).length, 9, 'Harus ada 9 kota');
assert.equal(data.filter(d => !d.kabupaten_kota.startsWith('Kota ')).length, 29, 'Harus ada 29 kabupaten');
for (const row of data) {
  assert.equal(row.tahun, 2025);
  assert.ok(coords[row.kabupaten_kota], 'Koordinat tidak ditemukan: ' + row.kabupaten_kota);
  for (const metric of ['sekolah_sd', 'sekolah_smp', 'sekolah_sma', 'guru_sd', 'guru_smp', 'guru_sma', 'murid_sd', 'murid_smp', 'murid_sma'])
    assert.ok(Number.isInteger(row[metric]) && row[metric] >= 0, `${row.kabupaten_kota}: ${metric} tidak valid`);
  assert.ok(Number.isFinite(row.ipm) && row.ipm >= 0 && row.ipm <= 100);
}
console.log('LULUS: jumlah wilayah, tahun, struktur indikator, dan koordinat.');
